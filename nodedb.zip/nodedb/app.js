const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const expressVlidator = require('express-validator');
const flash = require('connect-flash');
const session = require('express-session');
const passport = require('passport')
const config = require('./config/database');
const zomato = require('zomato');

mongoose.connect(config.database,{ useNewUrlParser: true });

var db = mongoose.connection;

// Zomato inislivatio

var client = zomato.createClient({
  userKey: 'edd3890c95e0970ddbd97160abf31dba',
});

//Social share

var share = require('social-share');
var url = share('twitter', {
    title:'share it'
});

//ceck
db.once('open',function(){
	console.log("conneced with monggose");
}) 

db.on('error',function(err) { 
	console.log(err);
});

const app = express();

//model

var Article = require('./models/article');
var Account = require('./models/account');
var Cart = require('./models/cart');
// load view engin

app.set('views',path.join(__dirname,'views'));
app.set('view engine','pug');


//miwaer bosy paerser

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json());

//public

app.use(express.static(path.join(__dirname,'public')));



//Express Session Middleware

app.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized: true
}))


// Express Message

app.use(require('connect-flash')());
app.use(function (req, res, next) {
  res.locals.messages = require('express-messages')(req, res);
  next();
});


// Validator
app.use(expressVlidator({
	errorFormatter:function(param,msg,value){
		var namespace = param.split('.')
		, root = namespace.shift()
		, formParam = root;

		while(namespace.lenght){
			formParam += '[' + namespace.shift() + ']';
		}

		return {
			param : formParam,
			msg : msg,
			value : value
		};
	}
}));

require('./config/passport')(passport)

//Passport mideeware
app.use(passport.initialize());
app.use(passport.session());

app.get('*',function(req,res,next){
	res.locals.user = req.user || null;
	next();
});



//Home Routh

// app.get('/',function(req,res) {

// 	Article.find({},function(err,articals){

// 		if(err){
// 			console.log("ther is error");
// 		}
// 		else {

// 		res.render("index",{
// 		title : 'ki',
// 		art:articals
// 	});
// 		}

// 	})

// });

app.get('/',function(req,res) {

	Article.find({},function(err,articals){

		if(err){
			console.log("ther is error");
		}
		else {
		d = {"categories":[{"categories":{"id":1,"name":"Delivery"}},{"categories":{"id":2,"name":"Dine-out"}},{"categories":{"id":3,"name":"Nightlife"}},{"categories":{"id":4,"name":"Catching-up"}},{"categories":{"id":5,"name":"Takeaway"}},{"categories":{"id":6,"name":"Cafes"}},{"categories":{"id":7,"name":"Daily Menus"}},{"categories":{"id":8,"name":"Breakfast"}},{"categories":{"id":9,"name":"Lunch"}},{"categories":{"id":10,"name":"Dinner"}},{"categories":{"id":11,"name":"Pubs & Bars"}},{"categories":{"id":13,"name":"Pocket Friendly Delivery"}},{"categories":{"id":14,"name":"Clubs & Lounges"}}]}
		client.getCollections({
city_id:"1", //id of the city for which collections are needed
lat:"28.613939", //latitude
lon:"77.209021", //longitude
count:"4" // number of maximum result to display
		}, function(err, result){
		    if(!err){
		    	var coin = 0;
		    	var coll = 0;
		      	// console.log(typeof result);
		      	// console.log(d.categories);
		      	var da = JSON.parse(result);
		      	// console.log(da.collections);
		      	if (req.user){
				Cart.count({ "cartid": req.user._id },function(err,count){
					if(err){
						console.log(err);
					}
					else{
						if(count=== null){
							req.session.coll = 0
						}
						else{
						console.log(count);
						req.session.coll = count
						}

					}
				}),
					
		   	Account.findById(req.user._id,function(err,account){ 
			if(err){
				console.log("not user");
			}
			else {
				if (account === null){
					console.log("null");
					coin = 0;
				}
				else {
					coin = account.coints;
				}
				req.session.email = coin
				console.log(req.session.email);
				console.log(req.session.coll);
					res.render("index",{
					title : 'Welcome Loyalty Program Web Application',
					art:articals,
					data:da,
					d: d,
					coin: coin,
					coll: req.session.coll
				});			
				}

			});
		      	}
		     else{

		     	req.session.email = coin
		      	res.render("index",{
					title : 'Welcome Loyalty Program Web Application',
					art:articals,
					data:da,
					d: d,
					coin: coin
				});
		    }
		}

		else {
		      console.log(err);
		    }
		});
		
		
		}

	})

});


// rOTER fILES

var articles = require('./routes/articles');
var users = require('./routes/users');
app.use('/articles',articles);
app.use('/users',users);



app.listen(3000,function() {
	console.log("sever stared on port 3000");
});
