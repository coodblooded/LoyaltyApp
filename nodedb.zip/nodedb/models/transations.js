var mongoose = require('mongoose');

var transationsSchema = mongoose.Schema({
	cartid:{
		type:String,
		required:true
	},
	name:{
		type:String
	},
	restid:{
		type:String
	},
	adddate:{
		type:String
	},
	numcoins:{
		type:Number
	},
	transtype:{
		type:String
	}


});

var Transactions = module.exports = mongoose.model('Transactions',transationsSchema);