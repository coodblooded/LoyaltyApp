var mongoose = require('mongoose');


var accountSchema = mongoose.Schema({
	cartid:{
		type:String,
		required:true
	},
	coints:{
		type:Number
	}

});

var Account = module.exports = mongoose.model('Account',accountSchema);