var mongoose = require('mongoose');


var articleSchema = mongoose.Schema({
	title:{
		type:String
	},
	author:{
		type:String
	},
	body:{
		type:String
	},
	restid:{
		type:String
	},
	datepodt:{
		type:String
	}
});

var Article = module.exports = mongoose.model('Article',articleSchema);