var mongoose = require('mongoose');

var cartSchema = mongoose.Schema({
	cartid:{
		type:String,
		required:true
	},
	name:{
		type:String
	},
	restid:{
		type:String
	},
	adddate:{
		type:String
	},
	restype:{
		type:String
	}


});

var Cart = module.exports = mongoose.model('Cart',cartSchema);