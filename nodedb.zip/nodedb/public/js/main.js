$(document).ready(function(){
	$(".delete-article").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');

		$.ajax({
			type:'DELETE',
			url:'/articles/'+id,
			success:function(response){
				alert('Delteeg');
				window.location.href='/'
			},

			error:function(err){
				console.log(err);
			}
		})
	});
	$("#myid").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
				type:'POST',
				url:'/articles/account/'+id,
				success:function(response){
				alert('Card Generate Successfully!!');
				window.location.href='/'
			},

			error:function(err){
				console.log(err);
			}
		})
	});

	$("#collct").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
				type:'POST',
				url:'/articles/addcollection/'+id,
				success:function(response){
				alert('Add  Successfully!!');
				window.location.href='/'
			},

			error:function(err){
				console.log(err);
			}
		})
	});

	$("#deletcoll").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
			type:'DELETE',
			url:'/articles/collectionslist/'+id,
			success:function(response){
				alert('Collection Delete Successfully!!');
				window.location.href='/'
			},

			error:function(err){
				console.log(err);
			}
		})
	});

	$("#reddemc").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
				type:'POST',
				url:'/articles/usecoins/'+id,
				success:function(response){
				alert('Successfully!!');
				window.location.href='/'
			},

			error:function(err){
				alert("Sorry You have Insufficient Coins Please By Coins for this deal");
				window.location.href='/articles/account/your'
			}
		})
	});
	$("#GOLD").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
				type:'PATCH',
				url:'/articles/buycoins/'+id,
				success:function(response){
				alert('You have purched conis  Successfully!!');
				window.location.href='/articles/account/your'
			},

			error:function(err){
				alert("Sorry Something Woang please Tye Again");
				window.location.href='/articles/account/your'
			}
		})
	});
	$("#DIAMOND").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
				type:'PATCH',
				url:'/articles/buycoins/'+id,
				success:function(response){
				alert('You have purched conis  Successfully!!');
				window.location.href='/articles/account/your'
			},

			error:function(err){
				alert("Sorry Something Woang please Tye Again");
				window.location.href='/articles/account/your'
			}
		})
	});
	$("#PREMIUM").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		$.ajax({
				type:'PATCH',
				url:'/articles/buycoins/'+id,
				success:function(response){
				alert('You have purched conis  Successfully!!');
				window.location.href='/articles/account/your'
			},

			error:function(err){
				alert("Sorry Something Woang please Tye Again");
				window.location.href='/articles/account/your'
			}
		})
	});
	$("#FACB").on('click',function(e){
		$target = $(e.target);
		var id =  $target.attr('data-id');
		var data = JSON.parse(id)
		$.ajax({
				type:'POST',
				url:'/articles/earncoin/'+data.id,
				success:function(response){
				alert('Nice Job You have earned 10 coins!!');
				window.location.href='http://www.facebook.com/sharer.php?t='+data.name+'&u=http://localhost.com:3000/articles/usecoins/'+data.restid
			},

			error:function(err){
				alert("Sorry You have Insufficient Coins Please By Coins for this deal");
				window.location.href='/articles/account/your'
			}
		})
	});
});

var states = [
			'Bhopal', 'indore', 'Pune', 'Surat', 'Mumbai',
			'Vijayawada', 'Thiruvananthapuram', 'Ajmer', 'Florida', 'Allahabad', 'Hawaii',
			'Idaho', 'Illinois', 'Bengaluru', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
			'Delhi NCR', 'Nagpur', 'Mysore', 'Kochi', 'Manali',
			'Pushkar', 'Missouri', 'Madurai', 'Chennai', 'Nevada', 'New Hampshire',
			'Mysore', 'Jaipur', 'New York', 'Vellore', 'North Dakota',
			'Chandigarh', 'Goa', 'Oregon', 'Pennsylvania', 'Rhode Island',
			'Noida', 'South Dakota', 'Gurgaon', 'Jabalpur', 'Utah', 'Rishikesh',
			'Mumbai', 'Kanpur', 'Udaipur', 'Jhansi', 'Kolkata'
		];
$('#auto1').autocomplete({
		source: [states]
	});



$('button selector').click(function(){
   window.location.href='http://localhost:3000/articles/bhopal';
})