const express = require('express');
const path = require('path');
const router = express.Router();
const passport = require('passport');
var bcrypt = require('bcryptjs');
//model User

var User = require('../models/user');


//Regisert Frm

router.get('/register', function(req,res){
	res.render('register');
})

//Regidet pocess
router.post('/register', function(req,res){
	var name = req.body.name;
	var email = req.body.email;
	var username = req.body.username;
	var password = req.body.password;
	var password2 = req.body.password2;

	req.checkBody('name','Name is Required').notEmpty();
	req.checkBody('email','Email is Required').isEmail();
	req.checkBody('username','Username is Required').notEmpty();
	req.checkBody('password','Password is Required').notEmpty();
	req.checkBody('password2','Pawword do not match').equals(req.body.password);

	var errors = req.validationErrors();

	if(errors){
		res.render('register',{
			errors:errors
		});
	}
		else {
			var newUser = new User({
				name:name,
				email:email,
				username:username,
				password:password
			});

			bcrypt.genSalt(10,function(err,salt){
				bcrypt.hash(newUser.password,salt,function(err,hash){
					if(err){
						console.log(err);
					}
					else {
						newUser.password = hash;
						newUser.save(function(err){
							if(err){
								console.log(err);
								return;
							}
							else {
								req.flash('success','You are now Resistered and can lon In');
								res.redirect('/users/login');
							}
						})
					}
				});
			});
		}

})

//Login form
router.get('/login',function(req,res){
	res.render('login');
})

// Login Porcesss
router.post('/login',function(req,res,next){
	passport.authenticate('local',{
		successRedirect:'/',
		failureRedirect:'/users/login',
		failureFlash:true
	})(req,res,next);

});


//Logout

router.get('/logout',function(req,res){
	req.logout();
	req.flash('success','You are Logge out');
	res.redirect('/users/login')
})

module.exports = router;