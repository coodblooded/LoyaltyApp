const express = require('express');
const zomato = require('zomato');
const router = express.Router();

//model Article

var Article = require('../models/article');

//Model User
var User = require('../models/user');

//Modal for Account
var Account = require('../models/account');

//Cart Model
var Cart = require('../models/cart');

//Transaction Modal

var Transactions = require('../models/transations');
//For Zomato API

//

var share = require('social-share');
var url = share('twitter', {
    title:'share it'
});

var client = zomato.createClient({
  userKey: 'edd3890c95e0970ddbd97160abf31dba',
});


router.get('/product',ensureAutheticated,function(req,res) {
	res.render('product_list',{
		title:"add ggtgb"
	});
});


//add submit

router.post('/product',function(req,res){

	req.checkBody('title','Title is required').notEmpty();
	// req.checkBody('author','Author is required').notEmpty();
	req.checkBody('body','Body is required').notEmpty();

	//Get Eror
	var errors = req.validationErrors();
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd = '0'+dd
	} 

	if(mm<10) {
	    mm = '0'+mm
	} 

	today = mm + '/' + dd + '/' + yyyy;
	if(errors){
		res.render('product_list',{
			title:"add ggtgb",
			errors: errors
		});
	}
	else {
	var article = new Article();
	article.title = req.body.title;
	article.author = req.user._id;
	article.body = req.body.body;
	article.restid = req.body.restid;
	article.datepodt = today;

	article.save(function(err){
		if(err){
			console.log(err);
			return;
		}

		else {
			req.flash('success','Review Added');
			res.redirect('/');
		}
	});
	}

});


//edit ingle article

router.get('/edit/:id',ensureAutheticated,function(req,res){
	Article.findById(req.params.id,function(err,article){
		if(article.author != req.user._id){
			req.flash('danger','Not Authorized');
			res.redirect('/');
		}
		 
		res.render('edit_article',{
			title:"Edit form",
			article:article
		});
	});
})


router.post('/edit/:id',function(req,res){
	var article = {};
	article.title = req.body.title;
	article.author = req.body.author;
	article.body = req.body.body;

	var query = {_id:req.params.id}
	Article.update(query,article,function(err){
		if(err){
			console.log(err);
			return;
		}

		else {
			req.flash('success','List Updated');
			res.redirect('/');
		}
	})
});


router.delete('/:id',function(req,res){
	var query = {_id:req.params.id};
	Article.remove(query,function(err){
		if(err){
			console.log(err);
		}

		res.send('secfvv');
	});
});


// router.get('/:id',function(req,res){
// 	Article.findById(req.params.id,function(err,article){
// 		User.findById(article.author,function(err,user){
// 		res.render('article',{
// 			article:article,
// 			author:user.name
// 			});	
// 		});

// 	});
// })

//get name info

router.get('/:id',function(req,res){
	console.log(req.params.id);
	client.getLocations({
		query:req.params.id, // suggestion for location name
		}, function(err, result){
		    if(!err){
		      console.log(result);
		      r = JSON.parse(result)
		      client.getLocationDetails({
					entity_id:r.location_suggestions[0].entity_id, //location id obtained from locations api
					entity_type:r.location_suggestions[0].entity_type //location type obtained from locations api
					}, function(err, result){
					    if(!err){
					      // console.log(result);

					       res.render('article',{
							 	article:JSON.parse(result),
							 	coin:req.session.email,
							 	coll:req.session.coll
							});	
					    }else {
					      console.log(err);
					    }
					});
		    }else {
		      console.log(err);
		    }
		});
})

//mANAGE aCCOUNT api

router.get('/account/:id',ensureAutheticated,function(req,res){
	Account.findById(req.user._id,function(err,account){ 
		if(err){
			console.log("not user");
		}
		else {
		if (account === null){
			// console.log(req.user._id);
				res.render('account',{
				title:"Your Sopping Card",
				article:account,
				coin:req.session.email,
				id:req.user._id,
				coll:req.session.coll
				});			
		}
		else {
		console.log(req.user._id);
		console.log(account.cartid);	
				res.render('account',{
				title:"Your Sopping Card",
				article:account,
				coin:req.session.email,
				coll:req.session.coll
				});				
		}	
			
		}

	});


})


//gGenerate New CARD API

router.post('/account/:id',function(req,res){
	console.log(req.params.id);
	Account.count({},function(err,c){
		if(err){
			console.log(err);

		}
		else {
			var s = 2583697414
			s = s + c
			console.log(s);
			var account = new Account();
			account._id = req.user._id;
			account.cartid = String(s);
			account.coints = 100;
			account.save(function(err){
				if(err){
					console.log(err);
				}

				res.send('secfvv');
			});
		}
	});

	

});


//Buy Coins API

router.get('/buycoins/:id',function(req,res){
	res.render('buycoins',{
		id : req.user._id,
		title:"Buy Coins",
		coin:req.session.email,
		coll:req.session.coll
	})
})


// Single Resorant and Order API


router.get('/addcart/:id',ensureAutheticated,function(req,res){
			client.getRestaurant({
			res_id:req.params.id // id of restaurant whose details are requested
			}, function(err, result){
			    if(!err){
					client.getReviews({
							res_id:req.params.id , // id of restaurant whose details are requested
							start : "0" , //fetch results after this offset (Integer)
							count: "2" 
							 
							}, function(err, review){
							    if(!err){
							res.render('addcart',{
								title:"Add Cart",
								coin:req.session.email,
								result :JSON.parse(result),
								review:JSON.parse(review),
								id:req.user._id,
								coll:req.session.coll

							})
						}else {
							  console.log(err);
							   }
					});

			    }else {
			      console.log(err);
			    }
			});
})

//Cart Add API

router.post('/addcollection/:id',function(req,res){
	var data = JSON.parse(req.params.id)
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd = '0'+dd
	} 

	if(mm<10) {
	    mm = '0'+mm
	} 

	today = mm + '/' + dd + '/' + yyyy;
	console.log(today);
	var cart = new Cart();
	cart.cartid = req.user._id;
	cart.name = data.name;
	cart.restid = data.restid;
	cart.restype = data.restype;
	cart.adddate = today;
	cart.save(function(err){
		if(err){
			console.log(err);
		}
		else {
			res.send("ddd");
		}
	})


})

//Get Colletion List API

router.get('/collectionslist/:id',function(req,res){
	console.log(req.params.id);
	Cart.find({"cartid":req.params.id},function(err,result){
		if(err){
			console.log(err);
		}else {
			res.render("collectionslist",{
				title:"Collection List",
				result:result,
				coin:req.session.email,
				coll:req.session.coll

			})
			console.log(result);
		}
	})
})


//Delete Collectionlist API
router.delete('/collectionslist/:id',function(req,res){
		var query = {_id:req.params.id};
		Cart.remove(query,function(err){
			if(err){
				console.log(err);
			}

			res.send('secfvv');
		});
	
})

//Browse API

router.get('/browse/:id',function(req,res){
	res.render('browse',{
		title:"Browse All Product",
		coin:req.session.email,
		coll:req.session.coll
	})
})


//Byu By Coins


// router.get('/usecoins/:id',ensureAutheticated,function(req,res){
// 			client.getRestaurant({
// 			res_id:req.params.id // id of restaurant whose details are requested
// 			}, function(err, result){
// 			    if(!err){
// 						Article.find({
// 							'restid':req.params.id 
// 							}, function(err, review){
// 							    if(!err){
// 							res.render('redeemcoin',{
// 								title:"Redeem Coins",
// 								coin:req.session.email,
// 								result :JSON.parse(result),
// 								review:JSON.parse(review),
// 								id:req.user._id,
// 								coll:req.session.coll,
// 								res_id:req.params.id

// 							})
// 						}else {
// 							  console.log(err);
// 							   }
// 					});

// 			    }else {
// 			      console.log(err);
// 			    }
// 			});
// })

router.get('/usecoins/:id',ensureAutheticated,function(req,res){
			client.getRestaurant({
			res_id:req.params.id // id of restaurant whose details are requested
			}, function(err, result){
				if(err){
					console.log(err);
				}else {
					Article.find({"restid":req.params.id },function(err,aricle){
						if(err){
							console.log(err);
						}
						else{
							console.log(aricle);
							if(aricle === null){
								aricle = []
							}
							else{
							res.render('redeemcoin',{
								title:"Redeem Coins",
								coin:req.session.email,
								result :JSON.parse(result),
								review:aricle,
								id:req.user._id,
								coll:req.session.coll,
								res_id:req.params.id

							})								
							}
						}
					})
				}
			});
})

//Redeem Coin Histry
router.post('/usecoins/:id',function(req,res){
	var data = JSON.parse(req.params.id)
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd = '0'+dd
	} 

	if(mm<10) {
	    mm = '0'+mm
	} 

	today = mm + '/' + dd + '/' + yyyy;
	if (req.session.email < data.coins){
		res.send(500);
	}
	else{
		Account.findById(req.user._id,function(err,account){
			if (err){
				console.log(err);
			}else {

				transactions = new Transactions();
				transactions.cartid = account.cartid;
				transactions.name = data.name;
				transactions.restid = data.restid;
				transactions.adddate = today;
				transactions.numcoins = data.coins;
				transactions.transtype = "Order";
				transactions.save(function(err){
					if(err){
						console.log(err);
					}
					else{

							var account1 = {}
							account1.cartid = account.cartid
							account1.coints = account.coints - data.coins ;
							var query = {_id:req.user._id}
							Account.update(query,account1,function(err){
								if(err){
									console.log(err);
									return;
								}else {
									res.send("Yes");
								}
							});
					}

				})
			}
		})

	}

})


//Buy coins with PATCH API

router.patch('/buycoins/:id',function(req,res){
	var data = JSON.parse(req.params.id)
	console.log(req.params.id)
	Account.findById(data.id,function(err,result){
	var account = {}
	account.cartid = result.cartid
	account.coints = data.coins + result.coints ;
	var query = {_id:data.id}
	Account.update(query,account,function(err){
		if(err){
			console.log(err);
			return;
		}else {
			res.send("Yes");
		}
	});
	})

});

//Transactions Heistary API

router.get('/transactions/:id',ensureAutheticated,function(req,res){
	Account.findById(req.user._id,function(err,result){
		if(err){
			console.log(err);
		}
		else {
		Transactions.find({"cartid":result.cartid},function(err,transactions){
			if(err){
				console.log(err);
			}else {
					res.render('transactions',{
					title:"Transactions History",
					id:req.user._id,
					coll:req.session.coll,
					coin:req.session.email,
					trans :transactions
				})
			}
		})
		}
	})
	

})


//GET Coinsform social nk API

router.post('/earncoin/:id',function(req,res){
	console.log(req.params.id);
	Account.findById(req.user._id,function(err,account){
		if(err){
			console.log(err);
		}else{
			var account1 = {}
			account1.cartid = account.cartid
			account1.coints = account.coints + 10 ;
			var query = {_id:req.user._id}
			Account.update(query,account1,function(err){
				if(err){
					console.log(err);
					return;
					}else {
							res.send("Yes");
					}
				});			
		}
	})

})

// Profile API

router.get('/profile/:id',ensureAutheticated,function(req,res){
	User.findById(req.user._id,function(err,info){
		if(err){
			console.log(err);
		}
		else{
			res.render('profile',{
				title:"Profile",
				id:req.user._id,
				coll:req.session.coll,
				coin:req.session.email,
				info:info

			})
		}
	})
})

//Access Control
function ensureAutheticated(req,res,next){
	if (req.isAuthenticated()){
		return next();
	}
	else {
		req.flash('danger','Please Login ');
		res.redirect('/users/login');	
	}
}


module.exports = router;